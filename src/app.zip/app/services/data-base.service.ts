// import { Injectable } from '@angular/core';
// import {Course, Grade, Student} from '../Models';
//
// @Injectable()
// export class DataBaseService {
//
//   constructor() { }
//   getMockData(): Student[] {
//     const student1 = new Student();
//     const course1 = new Course();
//     course1.courseName = 'Math';
//     const g1 = new Grade();
//     g1.value = 4.54;
//     const g2 = new Grade();
//     g2.value = 3.4;
//     const g3 = new Grade();
//     g3.value = 5;
//     course1.courseGrades = [g1, g2, g3];
//     student1.studentCourses = [course1];
//     student1.studentName = 'Jan';
//
//     const student2 = new Student();
//     const course2 = new Course();
//     course2.courseName = 'Ang';
//     const g4 = new Grade();
//     g4.value = 2.14;
//     const g5 = new Grade();
//     g5.value = 4.46;
//     const g6 = new Grade();
//     g6.value = 4.5;
//     course2.courseGrades = [g4, g5, g6];
//     student2.studentName = 'Ania';
//     student2.studentCourses = [course2];
//     console.log(student1);
//     return [student1, student2];
//   }
//
// }

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { catchError, map, tap } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import {Course, Grade, Student} from '../Models';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class DataBaseService {

  private studentsUrl = 'http://localhost:8080/students';

  constructor(private http: HttpClient) { }

  // getStudents(): Student[] {
  //   const student1 = new Student();
  //   const course1 = new Course();
  //   course1.courseName = 'Math';
  //   const g1 = new Grade();
  //   g1.value = 4.54;
  //   const g2 = new Grade();
  //   g2.value = 3.4;
  //   const g3 = new Grade();
  //   g3.value = 5;
  //   course1.courseGrades = [g1, g2, g3];
  //   student1.studentCourses = [course1];
  //   student1.studentName = 'Jan';
  //
  //   const student2 = new Student();
  //   const course2 = new Course();
  //   course2.courseName = 'Ang';
  //   const g4 = new Grade();
  //   g4.value = 2.14;
  //   const g5 = new Grade();
  //   g5.value = 4.46;
  //   const g6 = new Grade();
  //   g6.value = 4.5;
  //   course2.courseGrades = [g4, g5, g6];
  //   student2.studentName = 'Ania';
  //   student2.studentCourses = [course2];
  //   console.log(student1);
  //   return [student1, student2];
  // }

  /** GET students from the server */
  getStudents(): Observable<Student[]> {
    return this.http.get<Student[]>(this.studentsUrl);
  }

  /** POST: add a new student to the server */
  addStudent (student: Student): Observable<Student> {
    return this.http.post<Student>(this.studentsUrl, student, httpOptions).pipe(
      tap((studentAdded: Student) => this.log(`added student id=${studentAdded.id}`)),
      catchError(this.handleError<Student>('addStudent'))
    );
  }

  /** GET student by id. Will 404 if id not found */
  getStudent(id: number): Observable<Student> {
    const url = `${this.studentsUrl}/${id}`;
    return this.http.get<Student>(url).pipe(
      tap(_ => this.log(`fetched student id=${id}`)),
      catchError(this.handleError<Student>(`getStudent id=${id}`))
    );
  }

  /** DELETE: delete the student from the server */
  deleteStudent (student: Student | number): Observable<Student> {
    const id = typeof student === 'number' ? student : student.id;
    const url = `${this.studentsUrl}/${id}`;
    return this.http.delete<Student>(url, httpOptions).pipe(
      tap(_ => this.log(`deleted student id=${id}`)),
      catchError(this.handleError<Student>('deleteStudent'))
    );
  }

  /** PUT: update the student on the server */
  updateStudent (student: Student): Observable<any> {
    return this.http.put(this.studentsUrl, student, httpOptions).pipe(
      tap(_ => this.log(`updated student id=${student.id}`)),
      catchError(this.handleError<any>('updateStudent'))
    );
  }

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  /** Log a StudentService message with the MessageService */
  private log(message: string) {
    console.log('StudentService: ' + message);
  }

}
