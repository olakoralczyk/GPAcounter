export class Grade {
  id: number;
  value: number;
}
