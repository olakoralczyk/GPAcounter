import {Course} from './Course';

export class Student {
  id: number;
  studentName: string;
  studentCourses: Course[];
}
