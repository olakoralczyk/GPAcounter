import {Grade} from './Grade';

export class Course {
  id: number;
  courseName: string;
  courseGrades: Grade[];
}
