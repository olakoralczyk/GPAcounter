import { Component, OnInit } from '@angular/core';
import {Course, Grade, Student} from '../../Models';
import {DataBaseService} from '../../services/data-base.service';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {
  students: Student[];
  constructor(private data: DataBaseService) { }

  ngOnInit()    {
    this.data.getStudents()
      .subscribe(data => {
        console.log(data);
        this.students = data;
      });
  }

  addStudent() {
    const student = new Student();
    const course = new Course();
    const grade = new Grade();
    grade.value = 1;
    course.courseGrades = [grade];
    student.studentCourses = [course];
    this.students.push(student);
  }




}
